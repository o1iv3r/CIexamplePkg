library(testthat)
library(CIexamplePkg)

test_check("CIexamplePkg")
