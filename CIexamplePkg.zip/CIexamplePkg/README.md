# CIexamplePkg

<!-- badges: start -->
<!-- badges: end -->

The goal of CIexamplePkg is to provide a simple example on how to set up a package for continuous integration.
