test_that("addition works works", {
  expect_equal(2 + 2, 4)
})
